# CustomDancePlayer v0.1.2

## 中文

将 v0.1.1 之后已提交的改动同步到发行 DLL，保留现有安装方式与播放器界面。

- 支持递归扫描 `CustomDances` 子目录，按相对路径加载舞蹈。
- 播放前增加音频预热，改善动作与音频的启动同步。
- 更新窗口跟随与拖动检测，实现直接引用宿主 UniWindowController 程序集。
- 接入 **MMD 镜头演示**：设置中新增开关与缩放滑条，通过独立预览窗口显示动作内的镜头轨迹；支持关闭预览、停止后清除画面，并补充角色未就绪和换角色时的保护。
- 更新开发者包内 DLL，增加文件版本 `0.1.2.0`，保留程序集身份以兼容既有 prefab。
- 将可选工具 **DanceBundleAudioFixer** 一并提供：可修复部分旧 `.unity3d` 音频加载卡顿。工具沿用此前发布版本，README 已补充 MateEngine 目录选择、备份与恢复步骤。

### 安装与验证

下载 `CustomDancePlayer-v0.1.2.zip`，或下载单独的 `CustomDancePlayer.dll` 与 `CustomDancePlayer.me`。关闭游戏，备份旧 DLL/.me，然后按 README 替换插件 DLL、核对 ScriptingAssemblies 注册并导入配套 UI `.me`。保留舞蹈和设置，不要同时安装多个播放器 UI。此版保留现有 UI bundle 和脚本身份，由 DLL 在启动时创建、绑定镜头演示组件与控件。

在 Settings 中开启 **MMD camera demo**。舞蹈动画需包含 `Camera_root/Camera_root_1/Camera` 镜头轨迹；没有轨迹时预览显示等待提示。**Camera scale** 调整相对角色的镜头位置比例；此为镜头预览，不改变桌面主镜头。只需安装本版 DLL 与 `.me`，不需要手动挂组件或配置 RenderCamera。

候选 DLL 引用 GitHub 官方 MateEngine X3.3-HOTFIX-1 原始 Managed 编译通过（0 警告、0 错误），237 项宿主成员引用解析通过；已核查 UI prefab 的脚本类型、控件引用与开发者包 DLL 一致性。Unity 6000.2.6f2 中的 prefab / 镜头组件烟雾检查通过，覆盖控件创建、开关、位置缩放、FOV、停止与关闭按钮。尚未完成官方原版完整游戏内播放/视觉测试，Steam 3.4 不在本次兼容声明范围内。

本版本只支持旧 `.unity3d` 舞蹈。发行 `.me` 是播放器 UI，不是新增官方 `.me` 舞蹈支持。VMD / `.vmdance`、统一 **BepInEx** 加载、本地化、播放列表和贴近官方风格的新 UI 等大更新计划在 **0.2** 实现。

## English

Rebuilds the release DLL with changes committed after v0.1.1 while keeping the existing installation method and player UI.

- Recursive discovery and relative-path loading of dances in `CustomDances` subfolders.
- Audio warm-up for improved animation/audio startup synchronization.
- Updated window-follow and drag detection, with a direct reference to the host UniWindowController assembly.
- Includes the **MMD camera demo**: a settings toggle, camera scale slider, and an independent camera-track preview window, with close/stop behavior and guards for missing or changed avatars.
- Updated DLL in the developer archive; file version `0.1.2.0` with the existing assembly identity retained.
- Includes the previously published optional **DanceBundleAudioFixer**, which can fix audio-loading lag in some old `.unity3d` bundles. README now covers MateEngine folder selection, backups, and restoration.

Download the combined `CustomDancePlayer-v0.1.2.zip` or both standalone DLL and `.me` files. Close the game, back up the old files, and follow README to replace the DLL, check ScriptingAssemblies registration, and import the UI `.me`. Keep your dances/settings and avoid duplicate player UI instances. The existing UI bundle/script identities are retained; the DLL creates and binds the camera demo components and controls at startup.

Enable **MMD camera demo** in Settings. The dance animation needs tracks under `Camera_root/Camera_root_1/Camera`; without them, the preview shows a waiting message. **Camera scale** changes the camera position relative to the avatar. This preview leaves the main desktop camera unchanged. No manual component or RenderCamera setup is required.

Compiled against the original GitHub MateEngine X3.3-HOTFIX-1 Managed assemblies with no warnings/errors; all 237 checked host member references resolve. Prefab references and the developer archive DLL were checked. Unity 6000.2.6f2 prefab/component smoke checks passed for control creation, toggle binding, position/scale, FOV, stop, and close behavior. Full gameplay/visual validation on the original host has not been completed; this does not certify Steam 3.4 compatibility.

This version plays legacy `.unity3d` dances. The `.me` attachment is the player UI, not support for official `.me` dance playback. VMD / `.vmdance`, unified **BepInEx** loading, localization, playlists, and a new UI matching the official style are planned for **0.2**.
